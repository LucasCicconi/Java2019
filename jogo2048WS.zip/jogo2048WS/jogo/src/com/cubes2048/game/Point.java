package com.cubes2048.game;

/** 
    @version 1.1
    @see Ponteiro de posição
 */

public class Point 
{
    
    public int row;
    public int col;
    
    public Point(int row, int col)
    {
        this.row=row;
        this.col=col;
    }
    
}
