
package Server2048;

import com.google.gson.Gson;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;


/** 
    @author Lucas Cicconi Ferreira  17121393 || Derek, Freire Quaresma  18706986
    @version 1.1
    @see Classe Principal do Servidor
 */

@Path("Movimento")
public class MovimentoServer extends ArquivoServidor {

    @Context
    private UriInfo context;
    
    String Var=new String("teste");
    public MovimentoServer() {
    }
    
    @GET
    @Produces("application/Json")
    public String getJson() {
        
        String saida=Read();
        Gson g= new Gson();
        String aux=g.toJson(saida);
        Write("vazio");
        
        System.out.println(aux);
        return aux;
    }
    
    @POST
    @Consumes("application/json")
    @Path("alterar")
    public void putInserir(String content){
       //System.out.println(content);
        Write(content);
        Var=content;
    }
}
