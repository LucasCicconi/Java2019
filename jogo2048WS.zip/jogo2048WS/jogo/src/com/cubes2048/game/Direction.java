package com.cubes2048.game;

/** 
    @version 1.3
    @see Direções para uso nas Classes
 */

 enum Direction 
 {
    LEFT,
    RIGHT,
    UP,
    DOWN,
}

//V 1.3    02/10/19