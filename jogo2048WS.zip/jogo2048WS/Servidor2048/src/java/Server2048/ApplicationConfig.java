

package Server2048;

import java.util.Set;
import javax.ws.rs.core.Application;

/** 
    @version 1.0
    @see Classe WebService
 */

@javax.ws.rs.ApplicationPath("webresources")
public class ApplicationConfig extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<>();
        addRestResourceClasses(resources);
        return resources;
    }


    private void addRestResourceClasses(Set<Class<?>> resources) {
        resources.add(Server2048.MovimentoServer.class);
    }
    
}
