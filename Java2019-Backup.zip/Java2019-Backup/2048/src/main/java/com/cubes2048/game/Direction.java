package com.cubes2048.game;

/** 
    @version 1.1
    @see Direções para uso nas Classes
 */

public enum Direction {
    LEFT,
    RIGHT,
    UP,
    DOWN,
}

//test